<!DOCTYPE html>
<html>
 <head>
  <meta charset="UTF-8">
  <title>not a blog</title>
  <meta name="author" content="Thomas Lant">
  <meta name="description" content="A minimal blog.">
  <meta name="keywords" content="KEYWORDS,HERE">
  <link rel="stylesheet" href="http://b.3cu.eu/style.css" type="text/css">
 </head>
 <body>

  <div class="title">
   <a href="http://b.3cu.eu/">
    <h1>I don't have a blog</h1>
    <h2>but this is what I would write on it if I did</h2>
   </a>
  </div>
  <div class="entries">

<?php

function filter_bad_words($matches) {
    $swears = array("fuck"=>"frog", "shit"=>"shame", "cunt"=>"cone", "bollock"=>"balloon", "anus"=>"angus", "rape"=>"ping", "raping"=>"damaging", "rapist"=>"mime", "dick"=>"baguette", "twat"=>"hobbit", "arse"=>"frown", "wank"=>"shuffle", "crap"=>"craft", "penis"=>"wand", "cock"=>"pipe");
    $allowed = array("cocker", "manuscript", "manuscripts", "drape", "draped", "draper", "draperies", "drapers", "drapery", "drapes", "grape", "grapefruit", "grapes", "grapevine", "parapet", "parapets", "psychotherapeutic", "scrape", "scraped", "scraper", "scrapers", "scrapes", "skyscraper", "skyscrapers", "therapeutic", "trapezoid", "trapezoidal", "trapezoids", "physiotherapist", "psychotherapist", "therapist", "therapists", "scraping", "scrapings", "dickens", "dicky", "wristwatch", "wristwatches", "arsenal", "arsenals", "arsenic", "coarse", "coarsely", "coarsen", "coarsened", "coarseness", "coarser", "coarsest", "hoarse", "hoarsely", "hoarseness", "parse", "parsed", "parser", "parsers", "parses", "rehearse", "rehearsed", "rehearser", "rehearses", "sparse", "sparsely", "sparseness", "sparser", "sparsest", "unparsed", "swank", "swanky", "scrap", "scrapped", "scraps", "cocked", "cocking", "cockpit", "cockroach", "cocks", "cocktail", "cocktails", "cocky", "peacock", "peacocks", "shuttlecock", "stopcock", "stopcocks", "weathercock", "weathercocks", "woodcock", "woodcocks");

    $original_word = strtolower($matches[0]);
    $word = $original_word;
    if (in_array($word, $allowed)) return $matches[0];
    foreach ($swears as $key => $value) {
        $word = preg_replace("/".$key."/", $value, $word);
    }
    if ($word != $original_word) return "<a class='sw' href='entries/I_swear_too_much.entry'>" . $word . "</a>";
    return $matches[0];

}

$twitter = "@lampholder";

$specifile = $_REQUEST["file"];
if (isset($specifile)) {
    $file = "entries/" . substr($specifile, strrpos($specifile, '/' )+1);
    if (file_exists($file)) {
        $files = array($file);
    }
    $singlefile=True;
}
else {
    $files = glob('entries/*.entry');
    usort($files, function($a, $b) {
        return filemtime($a) < filemtime($b);
    });
}

$fp = True;
foreach($files as $file) {
    if (!$fp) print("<hr>" . PHP_EOL);
    $fp = False;
    print("<div class=\"entry\">" . PHP_EOL);
    print("<h1 class=\"entryTitle\">" . date('D, d M Y H:i:s e', filemtime($file)) . " - <a href=\"http://b.3cu.eu/$file\">$file</a></h1>" . PHP_EOL);
    print("<div class=\"entryBody\">" . PHP_EOL);
    print(preg_replace_callback('!\w+!', 'filter_bad_words', file_get_contents($file)));
    print("</div>" . PHP_EOL);
    print("<div class=\"entryControls\">" . PHP_EOL);
    $uniqueName = preg_replace("/.entry/", "", $file);
    $uniqueName = preg_replace("/entries\//", "", $uniqueName);
    print("<span class='twitter'>twitter</span>: <a href=\"http://twitter.com/intent/tweet?text=$twitter+ur+opinions+go+here&hashtags=db$uniqueName\">say things</a> <a href=\"http://twitter.com/#!/search/%23db$uniqueName\">read things</a>" . PHP_EOL);
    print("</div>");
    print("</div>" . PHP_EOL);
}

?> 

  </div>

  <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" type="text/javascript"></script>-->
  <img src="http://l2.3cu.eu/images/blog.gif" />
 </body>
</html>
